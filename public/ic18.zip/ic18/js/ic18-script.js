// IC18 – COSC 2328 – Professor McCurry
// Implemented by: jonn


// ─── Context ─

const HabitatContext = React.createContext();

// ─── Components


const Header = () => {
  // Consume context — no props needed
  const { mode } = React.useContext(HabitatContext);
  return (
    <header>
      <h1>🌍 Pixel's Habitat</h1>
      <p>{mode === 'day' ? '☀️ Day Mode' : '🌙 Night Mode'}</p>
    </header>
  );
};





// ─── Mount
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
